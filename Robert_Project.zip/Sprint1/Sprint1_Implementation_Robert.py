COIN_VALUES = {
    "penny": 0.01, "pennies": 0.01,
    "nickel": 0.05, "nickels": 0.05,
    "dime": 0.10, "dimes": 0.10,
    "quarter": 0.25, "quarters": 0.25
}

def coins_to_dollars(sentence: str) -> str:
    if not sentence or not sentence.strip():
        raise ValueError("Empty input")
    s = sentence.lower().strip()
    segments = [seg.strip() for seg in s.split(" and ") if seg.strip()]
    total = 0.0
    for seg in segments:
        parts = seg.split()
        if len(parts) != 2:
            raise ValueError("Malformed segment: " + seg)
        qty, denom = parts
        if not qty.isdigit():
            raise ValueError("Invalid quantity: " + qty)
        if denom not in COIN_VALUES:
            raise ValueError("Unknown denomination: " + denom)
        total += int(qty) * COIN_VALUES[denom]
    return f"{total:.2f}"
